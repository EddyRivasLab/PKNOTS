/* version.h
 * 
 */

#define RELEASE   "1.03"    
#define RELEASEDATE "OCT 2003"  

