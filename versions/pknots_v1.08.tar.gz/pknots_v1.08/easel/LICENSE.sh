export EASEL_VERSION=0.1.snap20080611 
export EASEL_DATE="June 2008"
export EASEL_COPYRIGHT="Copyright (C) 2008 Howard Hughes Medical Institute"
export EASEL_LICENSE="Freely distributed under the Janelia Farm Software License."

