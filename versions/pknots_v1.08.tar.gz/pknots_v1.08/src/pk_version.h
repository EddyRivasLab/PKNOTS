/* version.h
 * 
 */

#define RELEASE   "1.08"    
#define RELEASEDATE "2012"  

